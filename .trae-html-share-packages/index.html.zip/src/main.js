import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { registerStore } from '@/store'
import { useSvgIcon } from './icons'
import ElementPlus from 'element-plus'
import './permission'

import './styles/index.scss'
import './assets/fonts/index.css'
import 'element-plus/dist/index.css'
import './assets/iconfont/iconfont.css'
import registerDirective from '@/directive'
import { setupI18n } from '@/locale'
import { setupElementIcons } from '@/plugins/elementIcons'
import { useTable } from '@/plugins/vxeTable'

const app = createApp(App)

const initApp = async () => {
  app.use(router)
  useSvgIcon(app)
  registerStore(app)
  registerDirective(app)
  await router.isReady()
  setupI18n(app)
  setupElementIcons(app)
  app.use(ElementPlus)
  app.use(useTable)
  app.mount('#app')
  document.body.classList.add('vue-ready')
}
initApp()
